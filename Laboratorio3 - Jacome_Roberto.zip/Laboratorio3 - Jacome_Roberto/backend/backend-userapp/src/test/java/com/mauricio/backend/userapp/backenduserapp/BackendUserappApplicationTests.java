package com.mauricio.backend.userapp.backenduserapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendUserappApplicationTests {

	@Test
	void contextLoads() {
	}

}
