package com.mauricio.backend.userapp.backenduserapp.models;

public interface IUser {
    
    boolean isAdmin();
}
