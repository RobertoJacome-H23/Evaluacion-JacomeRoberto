package com.mauricio.backend.userapp.backenduserapp.services;

import java.util.List;
import java.util.Optional;

import com.mauricio.backend.userapp.backenduserapp.models.dto.UserDto;
import com.mauricio.backend.userapp.backenduserapp.models.entities.User;
import com.mauricio.backend.userapp.backenduserapp.models.request.UserRequest;

public interface UserService {
    
    List<UserDto> findAll();

    Optional<UserDto> findById(Long id);

    UserDto save(User user);
    Optional<UserDto> update(UserRequest user, Long id);

    void remove(Long id);
}
