package com.mauricio.backend.userapp.backenduserapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendUserappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendUserappApplication.class, args);
	}

}
