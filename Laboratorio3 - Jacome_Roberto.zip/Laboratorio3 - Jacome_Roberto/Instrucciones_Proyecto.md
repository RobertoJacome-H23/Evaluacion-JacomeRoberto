
# Instrucciones para Ejecutar el Proyecto

## 1. Configuración del Frontend

### Instala Node.js:

- Asegúrate de tener Node.js instalado en tu sistema. Puedes descargarlo desde [nodejs.org](https://nodejs.org/).

### Instala las Dependencias:

- Abre la terminal en la carpeta raíz del frontend (`frontend`).
- Ejecuta el siguiente comando para instalar todas las dependencias necesarias:

```bash
npm install
```

### Ejecuta el Proyecto:

- Una vez instaladas las dependencias, ejecuta el siguiente comando para iniciar el frontend:

```bash
npm run dev
```

- Esto levantará el servidor de desarrollo, y podrás ver la aplicación frontend en tu navegador.

## 2. Configuración del Backend

### Instala un Plugin de Spring para VS Code:

- Abre Visual Studio Code.
- Ve a la sección de extensiones y busca e instala el plugin de Spring Boot para VS Code. Esto te ayudará a manejar y ejecutar el proyecto de backend.

### Cargar los Servicios y Ejecutar el Proyecto:

- Abre el proyecto de backend en VS Code.
- El plugin de Spring Boot cargará automáticamente los servicios necesarios.
- Ejecuta el proyecto desde el plugin de Spring Boot o usando el terminal:

```bash
./mvnw spring-boot:run
```

### Base de Datos y Autenticación:

- El backend requiere un token para la autenticación al interactuar con la base de datos.
- Durante la ejecución, se te pedirá que ingreses un token de autorización.
- El proyecto también permite la creación de un nuevo usuario. La contraseña del usuario estará encriptada.
- Una vez autenticado, podrás ver y manejar el CRUD (Crear, Leer, Actualizar, Eliminar) para los datos a través del backend.
