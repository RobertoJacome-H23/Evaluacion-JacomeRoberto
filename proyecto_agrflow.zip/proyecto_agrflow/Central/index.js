const express = require('express');
const amqp = require('amqplib');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(express.json());

let cosechas = [];

async function connectRabbit() {
    const conn = await amqp.connect('amqp://localhost');
    const ch = await conn.createChannel();
    await ch.assertQueue('cola_inventario');
    await ch.assertQueue('cola_facturacion');
    return ch;
}

let channel;
connectRabbit().then(ch => channel = ch);

app.post('/cosechas', (req, res) => {
    const id = uuidv4();
    const cosecha = { id, ...req.body, estado: 'REGISTRADA' };
    cosechas.push(cosecha);

    // Publicar eventos
    channel.sendToQueue('cola_inventario', Buffer.from(JSON.stringify(cosecha)));
    channel.sendToQueue('cola_facturacion', Buffer.from(JSON.stringify(cosecha)));

    res.json({ mensaje: 'Cosecha registrada', cosecha });
});

app.get('/cosechas', (req, res) => {
    res.json(cosechas);
});

app.listen(3000, () => console.log("Central corriendo en puerto 3000"));
