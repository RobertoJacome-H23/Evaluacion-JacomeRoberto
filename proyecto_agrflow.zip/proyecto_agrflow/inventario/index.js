const amqp = require('amqplib');

let inventario = {
    "Semilla Arroz L-23": 1000,
    "Fertilizante N-PK": 500
};

async function start() {
    const conn = await amqp.connect('amqp://localhost');
    const ch = await conn.createChannel();
    await ch.assertQueue('cola_inventario');

    ch.consume('cola_inventario', msg => {
        const cosecha = JSON.parse(msg.content.toString());
        let semilla = cosecha.toneladas * 5;
        let fertilizante = cosecha.toneladas * 2;

        inventario["Semilla Arroz L-23"] -= semilla;
        inventario["Fertilizante N-PK"] -= fertilizante;

        console.log("Inventario actualizado:", inventario);
        ch.ack(msg);
    });
}

start();
