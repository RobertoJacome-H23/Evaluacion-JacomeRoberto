const amqp = require('amqplib');

const precios = {
    "Arroz Oro": 120,
    "Café Premium": 300
};

async function start() {
    const conn = await amqp.connect('amqp://localhost');
    const ch = await conn.createChannel();
    await ch.assertQueue('cola_facturacion');

    ch.consume('cola_facturacion', msg => {
        const cosecha = JSON.parse(msg.content.toString());
        const precio = precios[cosecha.producto] || 100;
        const total = cosecha.toneladas * precio;

        console.log(`Factura generada para ${cosecha.producto}: $${total}`);
        ch.ack(msg);
    });
}

start();
    